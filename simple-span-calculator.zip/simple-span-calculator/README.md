# simple-span-calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/jjcssfiddler/pen/XWBKxYO](https://codepen.io/jjcssfiddler/pen/XWBKxYO).

