/* way 1 */

const femaleChildren = 2;
const maleChildren = 1;

const totalChildren = femaleChildren + maleChildren;

console.log(totalChildren);

/* way 1 */

let totalChildren = 0;
const femaleChildren = 2;
const maleChildren = 1;
const animalChildren = 6;

totalChildren = totalChildren + animalChildren;

/*  way 2 */

//starting at 0 and adding to the code

let totalChildren = 0;
const femaleChildren = 2;
const maleChildren = 1;

totalChildren = totalChildren + femaleChildren;
// totalChildren = 0 + 2
console.log(totalChildren);

totalChildren = totalChildren + maleChildren;
console.log(totalChildren);

//shorthand way to do the calculations.

// take toal value of totalChildren and add it to femaleChildren
totalChildren += femaleChildren;

////////////////

let netIncome = 0;
const monthlyIncome = 2308.56;

const cableBill = 109.99;
const electricBill = 58.04;
const gasBill = 19.43;
const waterBill = 39.93;

netIncome = monthlyIncome - cableBill;

netIncome -= electricBill;
netIncome -= gasBill;
netIncome -= waterBill;

console.log(netIncome);
