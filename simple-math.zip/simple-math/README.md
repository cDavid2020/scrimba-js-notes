# simple math

A Pen created on CodePen.io. Original URL: [https://codepen.io/jjcssfiddler/pen/QWBNPvE](https://codepen.io/jjcssfiddler/pen/QWBNPvE).

