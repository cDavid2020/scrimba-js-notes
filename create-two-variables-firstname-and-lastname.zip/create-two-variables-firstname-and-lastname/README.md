# Create two variables, firstName and lastName

A Pen created on CodePen.io. Original URL: [https://codepen.io/jjcssfiddler/pen/BaPzqRp](https://codepen.io/jjcssfiddler/pen/BaPzqRp).

