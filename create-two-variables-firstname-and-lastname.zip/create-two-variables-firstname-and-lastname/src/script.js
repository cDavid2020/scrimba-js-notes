// Create two variables, firstName and lastName
let firstName = "Per";
let lastName = "Borgen";
// Concatenate the two variables into a third variable called fullName

let fullName = firstName + " " + lastName;
// to create a space in bet flname

// Log fullName to the console
console.log(fullName);
