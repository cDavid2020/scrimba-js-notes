let myPoints = 3;

// Create two functions, add3Points() and remove1Point(), and have them
// add/remove points to/from the myPoints variable

function add3Points() {
    myPoints += 3;
}

function remove1Points() {
    myPoints -= 1;
}

add3Points();
add3Points();
add3Points();
remove1Points();
remove1Points();

// Call the functions to that the line below logs out 10
console.log(myPoints);
